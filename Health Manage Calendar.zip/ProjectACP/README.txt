1. Member contribution : 1. Kittina Kunnahong --> user interface and algorithms of setting page.
                         2. Treepaech Treechan --> user interface and algorithms of home page and add activies page.
                         3. Natchapol Sirisang --> user interface and algorithms of show activies page, compile and review the program.
2. The best features of program : BMI system, option in setting page that can help user have good health along with good studies.
3. The features that you would like to improve : Click on any day and you can see the activity, Functions in raising activities, Make the interface more beautiful.
4. Other comments or suggestions : -
5. For teacher : Desktop Application of this program is in --> ProjectACP/dist/HealthManageCalendar.exe